import numpy as np
import ahrs
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import random as rd
from pyquaternion import Quaternion
import madgwickahrs as mg
import serial
import time
import math
import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *

ser = serial.Serial('/dev/cu.usbmodem14201', 115200) 
ma = mg.MadgwickAHRS(sampleperiod= 1.0 / 213.0)
count = 0

x_bias = 17.34766
y_bias = 2.85044
z_bias = -20.40367

verticies = [[1, -1, -1],[1, 1, -1],[-1, 1, -1],[-1, -1, -1],[1, -1, 1],[1, 1, 1],[-1, -1, 1],[-1, 1, 1]]
# ini_qua = Quaternion(0.05, -0.116, 0.984, 0.001)
# for i in range(len(verticies)):
#     verticies[i] = ini_qua.rotate(verticies[i])
final_verticies = [[1, -1, -1],[1, 1, -1],[-1, 1, -1],[-1, -1, -1],[1, -1, 1],[1, 1, 1],[-1, -1, 1],[-1, 1, 1]]
edges = [[0,1],[0,3],[0,4],[2,1],[2,3],[2,7],[6,3],[6,4],[6,7],[5,1],[5,4],[5,7]]



def Cube():
    glBegin(GL_LINES)
    for edge in edges:
        for vertex in edge:
            glVertex3fv(final_verticies[vertex])
    glEnd()



pygame.init()
display = (800,600)
pygame.display.set_mode(display, DOUBLEBUF|OPENGL)
gluPerspective(45, (display[0]/display[1]), 0.1, 10.0)
glTranslatef(0.0,0.0, -5)


#### for calibration
def calibrate():
    data1 = list(map(float, ser.readline().decode('utf-8').split(",")))[0:3]
    data2 = list(map(float, ser.readline().decode('utf-8').split(",")))[0:3]
    data3 = list(map(float, ser.readline().decode('utf-8').split(",")))[0:3]
    data4 = list(map(float, ser.readline().decode('utf-8').split(",")))[0:3]

    data1.append(0)
    data2.append(0)
    data3.append(0)
    data4.append(0)

    data1 = np.array(data1).astype("float64")
    data2 = np.array(data2).astype("float64")
    data3 = np.array(data3).astype("float64")
    data4 = np.array(data4).astype("float64")

    abc_1 = (-2*data1) - (-2*data2)
    abc_2 = (-2*data2) - (-2*data3)
    abc_3 = (-2*data3) - (-2*data4)
    b_1 = np.sum(data1*data1) - np.sum(data2*data2)
    b_2 = np.sum(data2*data2) - np.sum(data3*data3)
    b_3 = np.sum(data3*data3) - np.sum(data4*data4)
    abc_1[3] = b_1
    abc_2[3] = b_2
    abc_3[3] = b_3

    abc_1 = abc_1 / abc_1[0]
    abc_2 = abc_2 / abc_2[0]
    abc_3 = abc_3 / abc_3[0]

    bc_1 = abc_1 - abc_2
    bc_2 = abc_2 - abc_3

    bc_1 = bc_1 / bc_1[1]
    bc_2 = bc_2 / bc_2[1]

    c_m = bc_1 - bc_2

    c = - c_m[3] / c_m[2]
    b = - bc_1[3] - bc_1[2] * c
    a = - abc_1[3] - abc_1[2] * c - abc_1[1] * b

    print(a, b, c)

# while True:

#     data = list(map(float, ser.readline().decode('utf-8').split(",")))[0:3]
#     value = (data[0]-17.34766)*(data[0]-17.34766)+(data[1]-2.85044)*(data[1]-2.85044)+(data[2]+20.40367)*(data[2]+20.40367)
#     count += 1
#     if count == 100:
#         count = 0
#         print(math.sqrt(value))

mag_off = np.array([88.0, 2361.5, -2778.0])
mag_scale = np.array([5201.0, 5173.5, 5352.0])
st = 0
en = 0
while True:
    
    for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

    this_read = list(map(float, ser.readline().decode('utf-8').split(",")))[0:9]
    print(this_read)
    ma.update(np.array([this_read[3]/100, this_read[4]/100, this_read[5]/100]), np.array(this_read[0:3]), (np.array(this_read[6:9]) - mag_off) / mag_scale)
    # ma.update_imu([this_read[3]/100, this_read[4]/100, this_read[5]/100], [this_read[0], this_read[1], this_read[2]])
    my_qua = Quaternion(ma.quaternion._q[0], ma.quaternion._q[1], ma.quaternion._q[2], ma.quaternion._q[3])
    # print(my_qua)
    
    count += 1
    if count == 5:
        en = time.time()
        print(en - st)
        st = time.time()
        r, p, y = ma.quaternion.to_euler_angles()
        # print(round(r,4), "      ",round(p,4), "      ",round(y,4)) 
        # print(this_read[0:3])

        count = 0
        for i in range(len(final_verticies)):
            final_verticies[i] = my_qua.rotate(verticies[i])
        # print(final_verticies)
        glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
        Cube()
        pygame.display.flip()
        # pygame.time.wait(10)  

        
    